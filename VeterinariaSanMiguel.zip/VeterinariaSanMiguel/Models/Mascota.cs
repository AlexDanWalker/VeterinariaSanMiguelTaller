namespace VeterinariaSanMiguel.Models;

public class Mascota
{
    public int MascotaId { get; set; }     // PK
    public string Nombre { get; set; } = string.Empty;
    public string Especie { get; set; } = string.Empty; // Perro, Gato...
    public string? Raza { get; set; }
    public int Edad { get; set; }

    // FK -> Cliente
    public int ClienteId { get; set; }
    public Cliente? Cliente { get; set; }

    // Navegación Atenciones
    public List<Atencion> Atenciones { get; set; } = new();

    public override string ToString()
        => $"[{MascotaId}] {Nombre} ({Especie}{(Raza is null ? "" : $" - {Raza}")}) - Edad: {Edad} - Dueño: {Cliente?.Nombre ?? "(sin dueño)"}";
}