namespace VeterinariaSanMiguel.Models;

public class Atencion
{
    public int AtencionId { get; set; }    // PK
    public DateTime Fecha { get; set; } = DateTime.Now;
    public string? Diagnostico { get; set; }

    // FK Mascota (obligatoria)
    public int MascotaId { get; set; }
    public Mascota? Mascota { get; set; }

    // FK Veterinario (nullable)
    public int? VeterinarioId { get; set; }   // ahora acepta null
    public Veterinario? Veterinario { get; set; }

    public override string ToString()
        => $"[{AtencionId}] {Fecha:yyyy-MM-dd} - " +
           $"Mascota: {Mascota?.Nombre ?? "(id:" + MascotaId + ")"} - " +
           $"Vet: {Veterinario?.Nombre ?? (VeterinarioId.HasValue ? "(id:" + VeterinarioId + ")" : "(sin)")}) - " +
           $"Dx: {Diagnostico}";
}