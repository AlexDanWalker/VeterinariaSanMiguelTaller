using VeterinariaSanMiguel.Models;
using VeterinariaSanMiguel.Data;
namespace VeterinariaSanMiguel.Seeders;

public static class DbSeeder
{
    public static void Seed(VetContext context)
    {
        if (context.Clientes.Any()) return; // Evita duplicados

        // === CLIENTES (15) ===
        var clientes = new List<Cliente>
        {
            new Cliente { Nombre = "Juan Pérez", Email = "juan@mail.com", Telefono = "111111" },
            new Cliente { Nombre = "María Gómez", Email = "maria@mail.com", Telefono = "222222" },
            new Cliente { Nombre = "Carlos Ruiz", Email = "carlos@mail.com", Telefono = "333333" },
            new Cliente { Nombre = "Ana Torres", Email = "ana@mail.com", Telefono = "444444" },
            new Cliente { Nombre = "Pedro Sánchez", Email = "pedro@mail.com", Telefono = "555555" },
            new Cliente { Nombre = "Laura Martínez", Email = "laura@mail.com", Telefono = "666666" },
            new Cliente { Nombre = "Sofía Ramírez", Email = "sofia@mail.com", Telefono = "777777" },
            new Cliente { Nombre = "Diego López", Email = "diego@mail.com", Telefono = "888888" },
            new Cliente { Nombre = "Elena Herrera", Email = "elena@mail.com", Telefono = "999999" },
            new Cliente { Nombre = "Gabriel Castro", Email = "gabriel@mail.com", Telefono = "101010" },
            new Cliente { Nombre = "Patricia Vargas", Email = "patricia@mail.com", Telefono = "121212" },
            new Cliente { Nombre = "Andrés Ríos", Email = "andres@mail.com", Telefono = "131313" },
            new Cliente { Nombre = "Valentina Suárez", Email = "valentina@mail.com", Telefono = "141414" },
            new Cliente { Nombre = "Ricardo Torres", Email = "ricardo@mail.com", Telefono = "151515" },
            new Cliente { Nombre = "Daniela Ortega", Email = "daniela@mail.com", Telefono = "161616" }
        };

        // === VETERINARIOS (5) ===
        var veterinarios = new List<Veterinario>
        {
            new Veterinario { Nombre = "Dr. López", Especialidad = "Perros" },
            new Veterinario { Nombre = "Dra. Martínez", Especialidad = "Gatos" },
            new Veterinario { Nombre = "Dr. Fernández", Especialidad = "Aves" },
            new Veterinario { Nombre = "Dra. Ramírez", Especialidad = "Exóticos" },
            new Veterinario { Nombre = "Dr. Sánchez", Especialidad = "General" }
        };

        // === MASCOTAS (15–30) ===
        var mascotas = new List<Mascota>
        {
            new Mascota { Nombre = "Firulais", Especie = "Perro", Cliente = clientes[0] },
            new Mascota { Nombre = "Michi", Especie = "Gato", Cliente = clientes[0] },
            new Mascota { Nombre = "Rocky", Especie = "Perro", Cliente = clientes[1] },
            new Mascota { Nombre = "Luna", Especie = "Gato", Cliente = clientes[2] },
            new Mascota { Nombre = "Paco", Especie = "Loro", Cliente = clientes[2] },
            new Mascota { Nombre = "Nala", Especie = "Gato", Cliente = clientes[3] },
            new Mascota { Nombre = "Max", Especie = "Perro", Cliente = clientes[4] },
            new Mascota { Nombre = "Toby", Especie = "Perro", Cliente = clientes[5] },
            new Mascota { Nombre = "Kiwi", Especie = "Loro", Cliente = clientes[6] },
            new Mascota { Nombre = "Bella", Especie = "Gato", Cliente = clientes[7] },
            new Mascota { Nombre = "Simba", Especie = "Perro", Cliente = clientes[8] },
            new Mascota { Nombre = "Coco", Especie = "Conejo", Cliente = clientes[9] },
            new Mascota { Nombre = "Rex", Especie = "Perro", Cliente = clientes[10] },
            new Mascota { Nombre = "Chispas", Especie = "Gato", Cliente = clientes[11] },
            new Mascota { Nombre = "Daisy", Especie = "Perro", Cliente = clientes[12] },
            new Mascota { Nombre = "Thor", Especie = "Perro", Cliente = clientes[13] },
            new Mascota { Nombre = "Pelusa", Especie = "Gato", Cliente = clientes[14] }
        };

        // === ATENCIONES ===
        var atenciones = new List<Atencion>
        {
            // Firulais con 3 atenciones
            new Atencion { Mascota = mascotas[0], Veterinario = veterinarios[0], Diagnostico = "Vacunación" },
            new Atencion { Mascota = mascotas[0], Veterinario = veterinarios[0], Diagnostico = "Chequeo anual" },
            new Atencion { Mascota = mascotas[0], Veterinario = veterinarios[4], Diagnostico = "Problema dental" },

            // Michi con 2 atenciones
            new Atencion { Mascota = mascotas[1], Veterinario = veterinarios[1], Diagnostico = "Desparasitación" },
            new Atencion { Mascota = mascotas[1], Veterinario = veterinarios[1], Diagnostico = "Revisión general" },

            // Rocky con 2 atenciones
            new Atencion { Mascota = mascotas[2], Veterinario = veterinarios[0], Diagnostico = "Control general" },
            new Atencion { Mascota = mascotas[2], Veterinario = veterinarios[0], Diagnostico = "Vacunación" },

            // Luna con 3 atenciones
            new Atencion { Mascota = mascotas[3], Veterinario = veterinarios[1], Diagnostico = "Chequeo" },
            new Atencion { Mascota = mascotas[3], Veterinario = veterinarios[4], Diagnostico = "Dolor estomacal" },
            new Atencion { Mascota = mascotas[3], Veterinario = veterinarios[1], Diagnostico = "Vacunación" },

            // Paco con 2 atenciones
            new Atencion { Mascota = mascotas[4], Veterinario = veterinarios[2], Diagnostico = "Ala dañada" },
            new Atencion { Mascota = mascotas[4], Veterinario = veterinarios[2], Diagnostico = "Chequeo de recuperación" },

            // El resto con 1 atención
            new Atencion { Mascota = mascotas[5], Veterinario = veterinarios[1], Diagnostico = "Chequeo" },
            new Atencion { Mascota = mascotas[6], Veterinario = veterinarios[0], Diagnostico = "Vacuna antirrábica" },
            new Atencion { Mascota = mascotas[7], Veterinario = veterinarios[4], Diagnostico = "Revisión dental" },
            new Atencion { Mascota = mascotas[8], Veterinario = veterinarios[2], Diagnostico = "Problemas en el ala" },
            new Atencion { Mascota = mascotas[9], Veterinario = veterinarios[1], Diagnostico = "Revisión general" },
            new Atencion { Mascota = mascotas[10], Veterinario = veterinarios[0], Diagnostico = "Fractura" },
            new Atencion { Mascota = mascotas[11], Veterinario = veterinarios[3], Diagnostico = "Chequeo exótico" },
            new Atencion { Mascota = mascotas[12], Veterinario = veterinarios[0], Diagnostico = "Vacunación" },
            new Atencion { Mascota = mascotas[13], Veterinario = veterinarios[1], Diagnostico = "Chequeo" },
            new Atencion { Mascota = mascotas[14], Veterinario = veterinarios[4], Diagnostico = "Infección leve" },
            new Atencion { Mascota = mascotas[15], Veterinario = veterinarios[0], Diagnostico = "Desparasitación" }
        };

        context.Clientes.AddRange(clientes);
        context.Veterinarios.AddRange(veterinarios);
        context.Mascotas.AddRange(mascotas);
        context.Atenciones.AddRange(atenciones);

        context.SaveChanges();
    }
}
